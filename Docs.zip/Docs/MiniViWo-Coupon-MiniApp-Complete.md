# MiniViWo — Coupon Rationing Telegram Mini App

## Complete Technical & Product Documentation

---

## 1. What Is This?

MiniViWo is a **Telegram Mini App** that replaces physical rationing booklets with a digital coupon system for **post-war crisis relief in Iran**. It runs inside Telegram — no app store download needed — and serves as the fastest way to distribute essential supplies (water, food, fuel, hygiene, medical, energy) to **90 million people** across **27 million households**.

This is NOT the full ViWo super-app. This is a **stripped-down, purpose-built** coupon-only system designed to deploy in days, not months. The full ViWo app (payments, social, messaging) comes later. MiniViWo exists because:

- Telegram has ~85M users in Iran (95% penetration)
- No app store approval needed — instant deployment
- Works on any phone with Telegram installed (Android 5+, iOS 12+)
- No new account creation — Telegram identity IS the identity
- Government can reach the entire population through a single bot

---

## 2. The Problem We're Solving

After a war scenario, Iran's supply chain is disrupted. The government needs to:

1. **Identify** every household and its members
2. **Calculate** fair allocations based on family size, ages, and special needs
3. **Distribute** supplies through physical centers without chaos
4. **Prevent** fraud, double-claiming, and black market abuse
5. **Do all of this** for 90M people within days, not months

Paper booklets are slow, forgeable, and don't scale. A native app takes months of app store approvals. A Telegram Mini App can deploy **overnight** to 85M existing users.

---

## 3. How It Works — User Flow

### 3.1 First Time (Registration)

```
User opens Telegram → finds @ViWoMiniBot → taps "Open Mini App"
    → App loads in WebView (< 2 seconds)
    → Sees "Register Your Household" screen
    → Enters: national code (melli code), address, location
    → Taps "Register"
    → Backend: validates national code via Shahkar KYC API
    → Backend: creates household, auto-adds head member
    → Backend: calculates allocations for all 6 categories
    → User sees: dashboard with 6 category balances
```

### 3.2 Daily Use (Check Balances)

```
User opens Mini App
    → Sees 6 cards: Water, Food, Fuel, Hygiene, Medical, Energy
    → Each card shows: total / used / remaining / available this week
    → Weekly release schedule: Week 1 = 35%, Week 2 = 25%, Week 3 = 25%, Week 4 = 15%
    → Taps a category → sees detail view with history
```

### 3.3 At Distribution Center (Redeem)

```
User arrives at distribution center (government warehouse, private store, mobile unit)
    → Opens Mini App → selects category → enters amount
    → Taps "Generate QR Code"
    → Backend: validates balance, creates ECDSA-signed QR with 10-min expiry
    → QR appears on screen
    → Vendor scans QR → verifies signature → deducts from balance
    → User receives physical goods
    → App shows updated balance
```

### 3.4 Adding Family Members

```
User goes to "Household" tab
    → Sees current members
    → Taps "Add Member"
    → Enters: national code, name, birth date, gender, relationship
    → Optional: special flags (pregnant, chronic illness, disability, newborn)
    → Backend: recalculates ALL allocations based on new household composition
    → Balances update immediately
```

### 3.5 Dispute

```
User notices incorrect redemption in history
    → Taps the redemption → taps "Dispute"
    → Enters reason (min 10 characters)
    → Backend marks as disputed for investigation
```

---

## 4. The 6 Supply Categories

| Category | Unit | Example Items | Adult Monthly Base |
|----------|------|---------------|-------------------|
| **Water** | liters | Bottled/tanker water | 450 L (15L/day) |
| **Food** | kg | Rice, beans, oil, sugar, salt | 16.05 kg |
| **Fuel** | cylinders | Gas cylinders for cooking | 0.96 (household share) |
| **Hygiene** | items | Soap bars, sanitary pads | 4 items |
| **Medical** | kits | ORS packets, first-aid | 2.3 kits |
| **Energy** | items | Batteries, flashlights | 3.5 items |

---

## 5. Allocation Engine — How Amounts Are Calculated

This is the brain of the system. Every household gets a **need-based** allocation, not a flat amount.

### 5.1 Base Allocation by Age Group

Every household member gets a base allocation per category based on their age:

| Age Group | Water (L) | Food (kg) | Fuel | Hygiene | Medical | Energy |
|-----------|-----------|-----------|------|---------|---------|--------|
| Infant 0-6m | 270 | 0 | 0.96 | 10 | 2.3 | 3.5 |
| Infant 6-23m | 300 | 4 | 0.96 | 10 | 2.3 | 3.5 |
| Child 2-4 | 330 | 8 | 0.96 | 3 | 2.3 | 3.5 |
| Child 5-11 | 360 | 11 | 0.96 | 3 | 2.3 | 3.5 |
| Teen 12-17 | 450 | 14 | 0.96 | 4 | 2.3 | 3.5 |
| Adult 18-59 | 450 | 16.05 | 0.96 | 4 | 2.3 | 3.5 |
| Senior 60-64 | 450 | 16.05 | 0.96 | 4 | 2.3 | 3.5 |
| Elderly 65+ | 450 | 14 | 0.96 | 4 | 2.3 | 3.5 |

These numbers come from real procurement data (per 1,000,000 people, per 30 days).

### 5.2 Special Flag Multipliers

Members with special conditions get boosted allocations. The system uses **max-of** (not product) to prevent abuse:

| Flag | Food | Medical | Water | Hygiene |
|------|------|---------|-------|---------|
| Pregnant | 1.25x | 1.50x | 1.10x | — |
| Chronic illness | 1.10x | 14.00x | — | — |
| Sanitary (women 12-49) | — | — | — | 6.00x |
| Disability | — | 1.50x | — | 1.30x |
| Newborn | 1.30x | 1.20x | — | 1.50x |

Example: A pregnant woman with chronic illness gets `max(1.25, 1.10) = 1.25x` food, not `1.25 * 1.10 = 1.375x`.

### 5.3 Location Segment Multipliers

| Segment | Population % | Multiplier | Reason |
|---------|-------------|------------|--------|
| Tehran | 10.53% | 0.80x | Highest density, external supply dependent |
| Urban | 67.17% | 1.00x | Baseline |
| Rural | 22.30% | 1.20x | Logistics premium for delivery |

Tehran gets LESS because infrastructure concentrates supply there. Rural gets MORE because delivery costs are higher.

### 5.4 KYC Tier Factors

| Tier | Method | Factor | Meaning |
|------|--------|--------|---------|
| 1 — Digital | Shahkar API (SIM↔national code match) | 100% | Full allocation |
| 2 — Semi-offline | NFC card verified | 85% | Slightly reduced |
| 3 — Offline | Paper/community vouching | 70% | Reduced until upgraded |

### 5.5 Weekly Release Schedule

Allocations are monthly but released weekly to prevent hoarding:

| Week | Release % | Cumulative |
|------|-----------|------------|
| Week 1 | 35% | 35% |
| Week 2 | 25% | 60% |
| Week 3 | 25% | 85% |
| Week 4 | 15% | 100% |

Week 1 gets the most to cover immediate post-crisis needs.

### 5.6 Calculation Example

A Tehran household with:
- 1 adult male (35 years)
- 1 adult female (32 years, pregnant)
- 1 child (6 years)

**Water calculation:**
```
Adult male:    450 L × 1.0 (no flags) = 450 L
Adult female:  450 L × 1.10 (pregnant water boost) = 495 L
Child:         360 L × 1.0 = 360 L
                                        ─────────
Subtotal:                                1,305 L
× Tehran multiplier (0.80):              1,044 L
× KYC Tier 1 (1.00):                    1,044 L/month
Week 1 available (35%):                  365.4 L
```

---

## 6. Architecture

### 6.1 System Overview

```
┌─────────────────────────────────────────────┐
│              Telegram Client                 │
│  ┌───────────────────────────────────────┐  │
│  │     MiniViWo WebView (React SPA)      │  │
│  │  ┌─────┐ ┌─────┐ ┌─────┐ ┌────────┐ │  │
│  │  │Home │ │House│ │ QR  │ │History │ │  │
│  │  │Dash │ │hold │ │Gen  │ │       │ │  │
│  │  └─────┘ └─────┘ └─────┘ └────────┘ │  │
│  └──────────────┬────────────────────────┘  │
│                 │ HTTPS + initData auth      │
└─────────────────┼───────────────────────────┘
                  │
         ┌────────▼────────┐
         │   ALB (AWS)     │
         └────────┬────────┘
                  │
         ┌────────▼────────┐
         │  ECS Fargate    │
         │  Go Backend     │
         │  (mini-coupon)  │
         └───┬─────────┬───┘
             │         │
    ┌────────▼──┐  ┌───▼──────┐
    │ RDS       │  │ElastiCache│
    │ PostgreSQL│  │ Redis     │
    │           │  │           │
    └───────────┘  └───────────┘
```

### 6.2 Backend (Go) — Already Built & Running

**Module:** `github.com/viwo-app/mini-coupon`

**Stack:**
- Go 1.23
- Chi router (HTTP)
- pgxpool (PostgreSQL connection pool)
- go-redis (Redis for rate limiting)
- zap (structured logging)
- ECDSA P-256 (QR code signing)
- Snowflake IDs (distributed unique IDs)

**Layers:**
```
Handler (HTTP) → Service (Business Logic) → Repository (Database)
```

**API Endpoints (12 total):**

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/coupon/household` | Register household |
| GET | `/api/v1/coupon/household` | Get household summary |
| POST | `/api/v1/coupon/household/members` | Add family member |
| GET | `/api/v1/coupon/household/members` | List members |
| GET | `/api/v1/coupon/balances` | Get all 6 category balances |
| GET | `/api/v1/coupon/balances/{category}` | Get single category balance |
| POST | `/api/v1/coupon/qr/generate` | Generate signed QR code |
| POST | `/api/v1/coupon/redeem` | Redeem QR at distribution point |
| GET | `/api/v1/coupon/redemptions` | Redemption history (paginated) |
| POST | `/api/v1/coupon/redemptions/{id}/dispute` | Dispute a redemption |
| GET | `/api/v1/coupon/centers/nearby` | Nearby distribution centers |
| GET | `/api/v1/coupon/centers/{id}` | Distribution center detail |

**Authentication:** Telegram initData HMAC-SHA256 validation. No JWT. No user table. The Telegram user ID IS the identity.

**Database:** PostgreSQL only (5 tables: households, household_members, coupon_allocations, coupon_redemptions, distribution_centers). No ScyllaDB for this simplified deployment.

### 6.3 Frontend (To Be Built) — React Telegram Mini App

**Stack:**
- React 19 + TypeScript
- Vite 6 (build tool)
- `@tma.js/sdk-react` (Telegram SDK)
- TelegramUI (native Telegram components)
- Zustand (state management, 1.2KB)
- Tailwind CSS (styling, RTL-first)
- react-i18next (Persian/English)
- ky (HTTP client, 3KB)
- qrcode.react (QR generation)

**Why this stack (vibe coding optimized):**
- React has the most AI training data — Claude/GPT generate correct code on first try
- TelegramUI gives native Telegram look with zero design work
- Zustand is so simple AI never gets it wrong
- Vite has zero config — no build tool debugging
- Total bundle: ~106KB gzipped — loads in <1.5s on 3G

**Pages (7 screens):**

| Screen | Description |
|--------|-------------|
| **Home** | 6 category balance cards, overall status, quick actions |
| **Category Detail** | Single category: total/used/remaining, weekly chart, generate QR button |
| **QR Display** | Generated QR code with countdown timer (10 min expiry) |
| **Household** | Registration form (if new) or member list + add member |
| **History** | Redemption history with cursor pagination, dispute button |
| **Map** | Nearby distribution centers with distance and stock status |
| **Scanner** | QR scanner for distribution center vendors (camera access) |

**Language & Layout:**
- Persian (Farsi) is the primary language — RTL layout by default
- English as secondary language
- All strings via react-i18next localization keys
- RTL-first: layouts, icon direction, navigation flow

---

## 7. Authentication — Telegram initData

There is NO username/password. NO JWT tokens. NO user registration form.

When a user opens the Mini App, Telegram automatically sends `initData` — a signed payload containing the user's Telegram ID, name, and other info. The backend validates this using HMAC-SHA256:

```
1. Telegram sends initData to the Mini App WebView
2. Frontend passes initData in HTTP header: "Authorization: tma <initData>"
3. Backend:
   a. Parses initData as URL query params
   b. Extracts "hash" param
   c. Sorts remaining params alphabetically
   d. Joins as "key=value\n" (data-check-string)
   e. HMAC-SHA256("WebAppData", bot_token) → secret_key
   f. HMAC-SHA256(secret_key, data-check-string) → computed_hash
   g. Compares computed_hash with provided hash
   h. Validates auth_date is within 24 hours
   i. Extracts telegram_user_id from user JSON
4. telegram_user_id is used as the identity for all operations
```

**Why this is secure:**
- The hash can only be computed with the bot token (server-side secret)
- The initData is time-limited (24 hours)
- Telegram cryptographically guarantees the user identity
- No passwords to leak, no tokens to steal

---

## 8. QR Code Security — ECDSA P-256

Every QR code is cryptographically signed to prevent forgery:

```
QR Payload = {
    household_id: 12345,
    category: "food",
    amount: "2.5",
    coupon_code: "VC-98765",
    issued_at: "2026-04-06T00:27:17Z",
    expires_at: "2026-04-06T00:37:17Z",  // 10 min TTL
    tier: 1,
    nonce: "unique-random-string",
    signature: "ECDSA-P256-signature"
}
```

**Security measures:**
- **ECDSA P-256 signature** — Cannot be forged without the private key
- **10-minute expiry** — QR codes are useless after 10 minutes
- **Unique nonce** — Each QR can only be used once (DB constraint)
- **Low-S enforcement** — Prevents signature malleability attacks
- **Serializable transaction** — Balance deduction is atomic, prevents double-spend
- **Amount validation** — Cannot exceed available weekly balance

---

## 9. KYC — Shahkar API

Iran's Shahkar system matches a national code (melli code) to the SIM card registered to that person. This provides KYC without any document upload:

```
User enters national code → Backend sends to Shahkar API → 
    Match? → KYC Tier 1 (100% allocation)
    No match? → KYC Tier 3 (70% allocation, can upgrade later)
```

**In post-war context:**
- Shahkar API may be accessed via intermediaries (Finnotech, Kavoshak)
- Response time: < 500ms
- If Shahkar is down, user gets Tier 3 temporarily
- Community vouching can upgrade Tier 3 → Tier 2

---

## 10. Infrastructure & Deployment

### 10.1 AWS Architecture

| Component | AWS Service | Spec | Purpose |
|-----------|------------|------|---------|
| Compute | ECS Fargate | 256 CPU / 512MB | Go backend containers |
| Database | RDS PostgreSQL 16 | db.t3.micro, 20GB | All data storage |
| Cache | ElastiCache Redis 7 | cache.t3.micro | Rate limiting |
| Load Balancer | ALB | — | HTTPS termination, routing |
| Container Registry | ECR | — | Docker images |
| CDN | CloudFront | — | Frontend static assets |
| DNS | Route 53 | — | Domain management |
| Logs | CloudWatch | 14 day retention | Structured logging |

**Region:** `me-south-1` (Bahrain) — closest AWS region to Iran, lowest latency.

### 10.2 Local Development

```bash
cd /Users/mohamehr/Projects/MiniViWo/backend
make docker-up        # Start PostgreSQL + Redis in Docker
make migrate-up       # Apply database schema
make run-dev          # Start Go server on :8090
```

### 10.3 CI/CD Pipeline (GitHub Actions)

```
Push to main → Run Go tests → Build Docker image → Push to ECR → Terraform apply
```

Three jobs:
1. **test** — `go test ./...`
2. **build-and-push** — Docker build + ECR push (OIDC auth)
3. **deploy** — `terraform apply` (ECS service update)

### 10.4 Docker

- **Build:** Multi-stage (golang:1.23-alpine → alpine:3.20)
- **Binary:** Single static binary, ~15MB
- **docker-compose:** PostgreSQL 16 + Redis 7 + App (migrations auto-applied)

---

## 11. Database Schema

### 11.1 households
```sql
id               BIGINT PRIMARY KEY          -- Snowflake ID
telegram_user_id BIGINT NOT NULL UNIQUE      -- Telegram user ID (the identity)
household_code   VARCHAR(20) NOT NULL UNIQUE -- Human-readable code (HH-XXXXXXXXXX)
kyc_tier         INTEGER DEFAULT 1           -- 1=Digital, 2=Semi-offline, 3=Offline
address          TEXT                         -- Physical address
lat, lng         DOUBLE PRECISION            -- GPS coordinates
province_code    VARCHAR(5)                  -- Province (TH=Tehran, XX=default)
location_segment VARCHAR(20)                 -- tehran / urban / rural
status           VARCHAR(20)                 -- active / suspended / pending
created_at       TIMESTAMPTZ
updated_at       TIMESTAMPTZ                 -- Auto-updated by trigger
```

### 11.2 household_members
```sql
id              BIGINT PRIMARY KEY
household_id    BIGINT REFERENCES households(id)
national_code   VARCHAR(10) UNIQUE           -- Iranian national ID (melli code)
full_name       VARCHAR(200)
birth_date      DATE
gender          VARCHAR(10)                  -- male / female / other
relationship    VARCHAR(50)                  -- head / spouse / child / parent / etc.
age_group       VARCHAR(30)                  -- Computed from birth_date
special_flags   TEXT[]                       -- pregnant, chronic, disability, newborn, sanitary
kyc_verified    BOOLEAN DEFAULT FALSE
created_at      TIMESTAMPTZ
```

### 11.3 coupon_allocations
```sql
id                   BIGINT PRIMARY KEY
household_id         BIGINT REFERENCES households(id)
category             VARCHAR(20)              -- water/food/fuel/hygiene/medical/energy
cycle_start          TIMESTAMPTZ              -- First day of month
cycle_end            TIMESTAMPTZ              -- Last second of month
total_amount         NUMERIC(20,2)            -- Total monthly allocation
used_amount          NUMERIC(20,2)            -- Amount redeemed so far
remaining_amount     NUMERIC(20,2)            -- total - used
weekly_release_pct_* INTEGER × 4             -- 35, 25, 25, 15
current_week         INTEGER                  -- 1-4
status               VARCHAR(20)              -- active / expired / exhausted
created_at           TIMESTAMPTZ
```

### 11.4 coupon_redemptions
```sql
id                    BIGINT PRIMARY KEY
household_id          BIGINT REFERENCES households(id)
allocation_id         BIGINT
category              VARCHAR(20)
amount                VARCHAR(20)
coupon_code           VARCHAR(50)             -- VC-XXXXXXXXXXXX
distribution_point_id BIGINT
redeemed_by_member_id BIGINT
qr_nonce              VARCHAR(100) UNIQUE     -- Anti-replay protection
status                VARCHAR(20)             -- completed / disputed / reversed
created_at            TIMESTAMPTZ
```

### 11.5 distribution_centers
```sql
id              BIGINT PRIMARY KEY
name            VARCHAR(200)
type            VARCHAR(20)                  -- government / private / mobile
address         TEXT
lat, lng        DOUBLE PRECISION
categories      TEXT[]                       -- Which supply categories available
operating_hours VARCHAR(100)
queue_minutes   INTEGER                      -- Estimated wait time
stock_status    JSONB                        -- {"water": "in_stock", "food": "low"}
province_code   VARCHAR(5)
status          VARCHAR(20)                  -- open / closed / low_stock / out_of_stock
```

---

## 12. Rate Limiting

Redis-backed token bucket per Telegram user:

| Endpoint | Rate | Purpose |
|----------|------|---------|
| POST /household | 5/min | Prevent registration spam |
| POST /household/members | 5/min | Prevent member spam |
| POST /qr/generate | 20/min | Allow normal usage |
| POST /redeem | 10/min | Prevent redemption flooding |
| POST /redemptions/*/dispute | 5/min | Prevent dispute spam |
| GET endpoints | No limit | Read-heavy, low cost |

---

## 13. Error Handling

All errors follow a consistent JSON format:

```json
{
    "error": {
        "code": "INSUFFICIENT_BALANCE",
        "message": "Insufficient coupon balance for this category"
    }
}
```

| Code | HTTP Status | When |
|------|-------------|------|
| UNAUTHORIZED | 401 | Missing or invalid Telegram auth |
| FORBIDDEN | 403 | Trying to access another household's data |
| NOT_FOUND | 404 | Household not registered, allocation not found |
| BAD_REQUEST | 400 | Invalid input, expired QR, invalid category |
| DUPLICATE_ENTRY | 409 | National code already registered |
| INSUFFICIENT_BALANCE | 422 | Not enough allocation for requested amount |
| RATE_LIMITED | 429 | Too many requests |
| SERVICE_UNAVAILABLE | 503 | Database down |
| INTERNAL_ERROR | 500 | Unexpected server error |

---

## 14. Persian Digit Normalization

Iranian users type with Persian keyboards where digits are ۰۱۲۳۴۵۶۷۸۹ instead of 0123456789. The backend normalizes ALL numeric input:

```
۱۲۳۴۵۶۷۸۹۰ → 1234567890
٠١٢٣٤٥٦٧٨٩ → 0123456789  (Arabic-Indic also handled)
```

This happens before validation, so users can type national codes in either Persian or Western digits.

---

## 15. Frontend Design Requirements

### 15.1 Visual Language

- **TelegramUI components** — native Telegram look, no custom design needed
- **RTL-first** — Persian layout direction by default
- **Minimal** — no clutter, large touch targets, clear hierarchy
- **Accessible** — works for ages 15-65, WCAG AA contrast
- **Dark/Light** — follows Telegram's theme automatically via TelegramUI

### 15.2 Performance Targets

| Metric | Target | Why |
|--------|--------|-----|
| Bundle size | < 650KB gzipped | < 2s load on Iranian 3G |
| First paint | < 1.5s | User sees content fast |
| API response | < 500ms | Feels instant |
| QR generation | < 1s | No waiting at distribution center |

### 15.3 Offline Considerations

The Mini App requires network connectivity (it runs in Telegram's WebView). However:
- Cache last-known balances in localStorage for instant display
- Show stale data with "last updated X minutes ago" indicator
- Queue failed API calls for retry when connection restores
- QR codes work offline once generated (they contain all data)

---

## 16. Bot Setup

### 16.1 Bot Details

- **Bot Name:** ViWoMiniBot
- **Bot Token:** `8693627825:AAFtaFlq4c6Lv2loqooHPphjB_Y8U6PyqqU`
- **Mini App URL:** Set via BotFather → `/setmenubutton` → Web App URL

### 16.2 BotFather Configuration

```
/setname → ViWo Coupon
/setdescription → Digital coupon system for essential supplies distribution
/setmenubutton → Web App URL (after frontend deployment)
/setcommands →
    start - Open the coupon system
    help - Get help with using coupons
    balance - Check your coupon balances
```

---

## 17. Security Summary

| Threat | Mitigation |
|--------|-----------|
| Fake identity | Shahkar KYC (SIM↔national code match) |
| Forged QR codes | ECDSA P-256 signatures |
| Double spending | Unique nonce + DB constraint + Serializable TX |
| Replay attacks | 10-minute QR expiry + nonce uniqueness |
| Rate abuse | Redis token-bucket rate limiting |
| Data tampering | Telegram initData HMAC-SHA256 validation |
| Unauthorized access | Every endpoint verifies Telegram user ownership |
| SQL injection | Parameterized queries only (pgx) |
| Allocation fraud | Max-of multiplier stacking (not product) |
| Balance overflow | Cap at 999,999.99 per category, 128-bit precision math |

---

## 18. What's Built vs What's Next

### Done (Backend)
- [x] All 12 API endpoints running on port 8090
- [x] Telegram initData authentication
- [x] Complete allocation engine with procurement data
- [x] ECDSA QR code signing and verification
- [x] PostgreSQL schema with all constraints
- [x] Redis rate limiting
- [x] Snowflake ID generation
- [x] Persian digit normalization
- [x] Docker + docker-compose for local dev
- [x] Terraform for AWS ECS Fargate deployment
- [x] GitHub Actions CI/CD pipeline
- [x] End-to-end tested (21 tests passing)

### Next (Frontend)
- [ ] Scaffold React + TypeScript + Vite project
- [ ] Configure @tma.js/sdk-react
- [ ] Build 7 screens (Home, Category, QR, Household, History, Map, Scanner)
- [ ] Persian/English localization
- [ ] RTL layout
- [ ] Connect to Go backend API
- [ ] Deploy frontend to CloudFront/S3
- [ ] Configure BotFather menu button
- [ ] End-to-end test in real Telegram

### Future (Post-Launch)
- [ ] Shahkar KYC API integration (when available)
- [ ] Push notifications via Telegram bot messages
- [ ] Distribution center vendor app (separate Mini App)
- [ ] Analytics dashboard for government
- [ ] Migrate to full ViWo super-app when ready

---

## 19. File Structure

```
MiniViWo/
├── backend/                          # Go backend (DONE)
│   ├── cmd/server/main.go           # Entry point
│   ├── internal/
│   │   ├── config/                   # Viper config
│   │   ├── database/                 # PostgreSQL + Redis
│   │   ├── errors/                   # App error types
│   │   ├── httputil/                 # Response helpers
│   │   ├── idgen/                    # Snowflake IDs
│   │   ├── middleware/               # Telegram auth, rate limit, CORS, logging
│   │   ├── validator/                # Input validation
│   │   └── coupon/
│   │       ├── model/                # Domain types + DTOs
│   │       ├── repository/           # PostgreSQL queries
│   │       ├── service/              # Business logic + allocation engine
│   │       └── handler/              # HTTP handlers + routes
│   ├── migrations/                   # SQL DDL
│   ├── deploy/                       # Dockerfile, docker-compose, Terraform
│   ├── .github/workflows/            # CI/CD
│   ├── Makefile
│   └── .env
├── frontend/                         # React Mini App (TO BUILD)
│   ├── src/
│   │   ├── app/                      # TMA provider + router
│   │   ├── pages/                    # 7 screens
│   │   ├── components/               # Shared UI
│   │   ├── store/                    # Zustand stores
│   │   ├── api/                      # HTTP client
│   │   ├── i18n/                     # Persian + English
│   │   └── lib/                      # Utilities
│   ├── public/
│   ├── index.html
│   ├── vite.config.ts
│   ├── tailwind.config.ts
│   └── package.json
└── Docs/                             # This document
```

---

## 20. Cost Estimate (AWS Monthly)

| Resource | Spec | Monthly Cost |
|----------|------|-------------|
| ECS Fargate | 0.25 vCPU, 512MB, 1 task | ~$10 |
| RDS PostgreSQL | db.t3.micro, 20GB | ~$15 |
| ElastiCache Redis | cache.t3.micro | ~$12 |
| ALB | 1 ALB | ~$16 |
| CloudFront | Static frontend | ~$1 |
| ECR | Docker images | ~$1 |
| CloudWatch | Logs | ~$3 |
| **Total** | | **~$58/month** |

This scales to handle the initial rollout. For 90M users, scale to ECS auto-scaling + RDS r6g.large + ElastiCache r6g.large (~$500/month).

---

*Document created: 2026-04-06*
*Backend status: Running and tested*
*Frontend status: Architecture defined, awaiting implementation*
